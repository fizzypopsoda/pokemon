---
name: Bug report
about: Create a report to help us improve
---

<!--
Thanks for contributing to the PokéAPI project. To make sure we're effective, please check the following:

- Make sure your issue hasn't already been submitted on the issues tab. (It has search functionality!)
- If your issue is one of outdated API data, please note that we get our data from [veekun](https://github.com/veekun/pokedex/). If they are not up to date either, please look for or create an issue there. Otherwise, feel free to create an issue here. 
- Provide a clear description of the issue.
- Provide a clear description of the steps to reproduce.
- Provide a clear description of the expected behavior.

Thank you!
-->

Steps to Reproduce:

1.
2.
