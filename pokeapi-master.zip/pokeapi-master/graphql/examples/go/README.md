# Go examples

## `pokemon.go`

Fetches details about a Pokémon and prints an unformatted JSON to the `stdout`. The name of the Pokémon is passed as a variable.

```sh
go run pokemon.go # | jq
```
